﻿using UnityEngine;
using UnityEditor;

public class $safeitemname$ : ScriptableObject
{
    [MenuItem("Tools/MyTool/MyScriptableObject")]
    static void DoIt()
    {
        EditorUtility.DisplayDialog("MyTool", "MyScriptableObject", "OK", "");
    }
}