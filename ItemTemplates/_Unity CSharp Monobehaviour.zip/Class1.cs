﻿using UnityEngine;
using System.Collections;

public class $safeitemname$ : MonoBehaviour
{
    void Start()
    {

    }

    void Update()
    {

    }
}
