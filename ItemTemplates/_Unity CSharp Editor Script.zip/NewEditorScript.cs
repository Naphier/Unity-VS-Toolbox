﻿using UnityEngine;
using UnityEditor;

public class $safeitemname$ : Editor
{
    [MenuItem("Tools/MyTool/MyEditorScript")]
    static void DoIt()
    {
        EditorUtility.DisplayDialog("MyTool", "MyEditorScript", "OK", "");
    }
}