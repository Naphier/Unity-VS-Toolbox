﻿using UnityEngine;
using System.Collections;

public class $safeitemname$ : Singleton<$safeitemname$>
{
    protected $safeitemname$() { } // guarantee this will be always a singleton only - can't use the constructor!

    void Start()
    {

    }

    void Update()
    {

    }
}
